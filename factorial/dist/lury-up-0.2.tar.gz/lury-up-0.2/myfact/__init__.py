from fact import factorial
__all__ = [factorial, ]
#表示在fact模块中只有factorial函数能够导入到其他的模块中使用
